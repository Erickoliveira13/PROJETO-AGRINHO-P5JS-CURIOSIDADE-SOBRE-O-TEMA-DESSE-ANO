let olhoX
let olhoY

function setup() {
  createCanvas(1500, 500);
}

function draw() {
  background('#00BCD4');
  fill('brown')
  circle(350,250,400);//ROSTO
  fill('white')
  circle(250,190,100);//OLHO ESQUERDO
  circle(450,190,100);//OLHO DIREITO
  fill('rgb(10,45,241)')
  //circle(250,190,30);//PUPILA ESQUERDA 
  //circle(450,190,30);//PUPILA DIREITA
  triangle(311,277,346,220,384,277);// NARIZ
  fill(' #E91E63')
  line(220,127,282,111);//SOBRANCELHA ESQUERDA 
  line(419,111,482,127);//SOBRANCELA DIREITA 
  arc(345, 310, 100, 130, 0 , PI, );//BOCA
  line(295, 310, 394, 310);//LINHA EM CIMA DA BOCA 
  line(160, 287, 251, 294);
  line(162,317,251,323);//FLECHA ESQUERDA
  line(249,323,250,294);//FLECHA ESQUERDA
  fill('black')
  triangle(160,329,163,273,122,291);//FLECHA ESQUERDA
  fill('white')
  circle(60,290,100)//BALÃO DE FALA ESQUERDO
  fill('black')
  textSize(15)//TAMANHO DO TEXTO
  text("SABIA QUE",20,290);//);
  line(455,319,555,319);//FLECHA DIREITA
  line(455,319,455,345);//FLECHA DIREITA
  line(455,345,555,345);//FLECHA DIREITA
  triangle(555,357,555,311,583,330);//FLECHA DIREITA
  fill('white')
  circle(750,270,300);//BALÃO DE FALA DIREITO
  textSize(15)//TAMANHO DO TEXTO
  fill('black')
  text('"Festejando a conexão campo-cidade"',627,250);
  text('visa destacar a independência entre',625,265);
  text('o meio rural e o urbano',680,280);
  olhoX = map(mouseX,0,700,221,281);
  olhoY = map(mouseY,0,700,152,227);
  
  fill('green')
  circle(olhoX,olhoY,30);
  circle(olhoX+200,olhoY,30);
  if(mouseIsPressed) {
    console.log(mouseX,mouseY);
  }
}
